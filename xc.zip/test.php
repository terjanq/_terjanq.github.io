<?php
echo 'lol'

?>